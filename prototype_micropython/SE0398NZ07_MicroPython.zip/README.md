# 华为手机壳 3.98 寸 4 色墨水屏软硬件全套项目

本项目包含华为/荣耀手机壳拆机 3.98 英寸四色电子墨水屏（型号：`SE0398NZ07-FNG-A0` / `A1/A0`）在 ESP32-C3 平台下的全套驱动源码、点阵资源、图片转换工具、演示应用，以及**专属定制的 24-Pin 0.8mm 转 0.5mm 45° 仿形 FPC 转接排线工程与嘉立创打样文件**。

---

## 一、 文件与目录清单

### 1. 软件驱动与演示应用（根目录）
| 文件 | 说明 | 运行平台 |
| :--- | :--- | :--- |
| **`epd3in98.py`** | 核心驱动库（支持双向物理交错扫描、大字号缩放渲染、Viper 机器码位序重排、零内存流式图片加载） | ESP32-C3 (MicroPython) |
| **`demo.py`** | 完整演示应用（包含大字号状态栏、参数卡片、4 色艺术头像与品牌标识） | ESP32-C3 (MicroPython) |
| **`avatar.raw`** | 280×280 四色落日头像点阵资源包（19.6 KB，MicroPython GS2_HMSB 位序对齐） | ESP32-C3 / PC |
| **`convert_image.py`** | PC 端图片转码工具（将任意 PNG/JPG 转换为 4 色 Floyd-Steinberg 抖动的 `.raw` 点阵文件） | PC (Python 3) |

### 2. 硬件 FPC 转接排线设计（`fpc/` 目录）
墨水屏原生出线为 **24-Pin 0.8mm 间距焊接端**，为了能直接插接到市场上通用的 **24-Pin 0.5mm 间距翻盖 ZIF 插座**，专门设计了 45° 仿形转接 FPC。

| 文件 / 目录 | 说明 |
| :--- | :--- |
| **`fpc/0.8_0.5_fpc_45degree_KiCad`** | KiCad PCB 版图设计源文件 |
| **`fpc/0.8_0.5_fpc_45degree.epro`** | 嘉立创 EDA 专业版工程总控文件 |
| **`fpc/README.md`** | FPC 详细设计规格书、引脚映射网络表与嘉立创下单要点 |
| **`standard_24pin.py`** | FPC 网络与标准 24-Pin 墨水屏引脚定义比对校验脚本 |

---

## 二、 硬件接线与引脚定义

MCU：**ESP32-C3 SuperMini**  
屏幕：**SE0398NZ07-FNG-A0**（768 × 552 点阵，4 色 BWRY）

| 墨水屏引脚 | ESP32-C3 GPIO | 功能说明 | 硬件电平特性 |
| :--- | :--- | :--- | :--- |
| **3.3V (VCC)** | 3V3 | 电源正极 | 3.3V 稳压输入 |
| **GND** | GND | 电源地 | 逻辑与高压地 |
| **DIN (MOSI)**| GPIO 6 | SPI 数据信号 | SPI1 MOSI (支持 8MHz+) |
| **CLK (SCK)** | GPIO 4 | SPI 时钟信号 | SPI1 SCK |
| **CS** | GPIO 7 | 片选信号 | 低电平有效 |
| **DC** | GPIO 1 | 数据/命令选择 | 0=命令 (CMD)，1=数据 (DATA) |
| **RST** | GPIO 2 | 硬件复位引脚 | 低电平复位脉冲 (40ms) |
| **BUSY** | GPIO 10 | 芯片状态输出 | **低电平=忙碌中 (0)，高电平=空闲就绪 (1)** |

---

## 三、 FPC 转接排线引脚映射 (1:1 纯硬件直连)

| Pin # | 信号名称 | 功能说明 | 屏幕端 (0.8mm 间距) | 驱动板端 (0.5mm 间距插拔端) |
| :---: | :---: | :---: | :---: | :---: |
| **1** | GDR | N-MOS 升压驱动脚 | Pad 1 | Pin 1 |
| **2** | RESE | 升压电流检测电阻脚 | Pad 2 | Pin 2 |
| **3** | VSH2 | 升压正高压 2 (+15V) | Pad 3 | Pin 3 |
| **4~7**| NC | 测试脚 / 悬空 | Pad 4~7 | Pin 4~7 |
| **8** | BS | 接口选择 (GND=4线SPI) | Pad 8 | Pin 8 |
| **9** | BUSY | 忙状态指示 (低电平忙) | Pad 9 | Pin 9 |
| **10**| RST | 复位信号 (低电平复位) | Pad 10 | Pin 10 |
| **11**| DC | 数据/命令选择 | Pad 11 | Pin 11 |
| **12**| CS | 片选信号 (低有效) | Pad 12 | Pin 12 |
| **13**| SCL | SPI 时钟信号 | Pad 13 | Pin 13 |
| **14**| SDA | SPI 数据输入信号 | Pad 14 | Pin 14 |
| **15**| VDDIO | 逻辑供电 (3.3V) | Pad 15 | Pin 15 |
| **16**| VCI/VDD | 模拟主供电 (3.3V) | Pad 16 | Pin 16 |
| **17**| VSS/GND | 系统参考地 | Pad 17 | Pin 17 |
| **18**| VDD | 内部核心稳压电容脚 | Pad 18 | Pin 18 |
| **19**| VPP | OTP 供电 | Pad 19 | Pin 19 |
| **20**| VCOM | 公共极电压 | Pad 20 | Pin 20 |
| **21**| VGL | 负偏压驱动 (-20V) | Pad 21 | Pin 21 |
| **22**| VGH | 正偏压驱动 (+22V) | Pad 22 | Pin 22 |
| **23**| VSL | 负驱动参考电压 | Pad 23 | Pin 23 |
| **24**| VSH1 | 正驱动参考电压 1 (+15V)| Pad 24 | Pin 24 |

---

## 四、 快速上手指南

### 如何在自己的 Python 代码中使用
```python
from machine import Pin, SPI
from epd3in98 import EPD_3in98, BLACK, WHITE, YELLOW, RED

# 硬件初始化
spi = SPI(1, baudrate=8000000, polarity=0, phase=0, sck=Pin(4), mosi=Pin(6))
cs   = Pin(7, Pin.OUT, value=1)
dc   = Pin(1, Pin.OUT, value=0)
rst  = Pin(2, Pin.OUT, value=1)
busy = Pin(10, Pin.IN)

epd = EPD_3in98(spi, cs, dc, rst, busy, panel_version='A0')

# 基础绘图 (继承自 MicroPython FrameBuffer)
epd.fill(WHITE)
epd.fill_rect(20, 20, 300, 100, BLACK)

# 大字号绘制 (支持 scale 放大倍数与加粗)
epd.draw_text("HELLO WORLD", 40, 50, WHITE, scale=3, bold=True)

# 零内存开销流式载入任意 4 色点阵图片
epd.blit_raw_2bpp("avatar.raw", 460, 180, 280, 280)

# 刷新到屏幕
epd.display()
```

### 转换任意新图片
在 PC 端使用 `convert_image.py`：
```bash
python convert_image.py my_photo.png my_photo.raw 280 280
```
该工具会自动应用 4 色 Floyd-Steinberg 误差扩散算法并生成预览图与 `.raw` 点阵文件。

